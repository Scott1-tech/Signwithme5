"""users.token_version: revoke issued JWTs.

Each access token carries the `token_version` it was issued with (`tv`). Bumping
the column ends every session of that user: a password change does it, and so
does POST /api/auth/me/sign-out-everywhere. Existing tokens have no `tv` and
count as 0, which matches the default, so nobody is signed out by the upgrade.

Revision ID: 0009
Revises: 0008
Create Date: 2026-11-27
"""
import sqlalchemy as sa
from alembic import op

revision = "0009"
down_revision = "0008"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column("token_version", sa.Integer(), nullable=False, server_default=sa.text("0")),
    )


def downgrade() -> None:
    op.drop_column("users", "token_version")
