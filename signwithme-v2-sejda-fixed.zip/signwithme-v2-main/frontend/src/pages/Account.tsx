import { useState, type FormEvent } from 'react';
import { api, tokenStore } from '../api/client';

/** Change your own password (POST /api/auth/me/password). */
export function Account() {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [repeat, setRepeat] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [sessionError, setSessionError] = useState<string | null>(null);

  const signOutEverywhere = async () => {
    if (!window.confirm('Sign out of every browser and device? You will need to sign in again.')) return;
    setSessionError(null);
    setSigningOut(true);
    try {
      await api.post('/api/auth/me/sign-out-everywhere', {});
      tokenStore.set(null);
      window.location.replace('/login');
    } catch (cause) {
      setSessionError(cause instanceof Error ? cause.message : 'Could not sign out everywhere');
      setSigningOut(false);
    }
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    setDone(false);
    if (next !== repeat) {
      setError('The two new passwords are not the same.');
      return;
    }
    setBusy(true);
    try {
      const result = await api.post<{ changed: boolean; access_token?: string }>(
        '/api/auth/me/password',
        { current_password: current, new_password: next },
      );
      // The change ends every other session; this one continues on the new token.
      if (result.access_token) tokenStore.set(result.access_token);
      setDone(true);
      setCurrent('');
      setNext('');
      setRepeat('');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not change the password');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page">
      <form className="card auth__card" onSubmit={submit}>
        <h1>Change password</h1>
        <label className="field">
          <span>Current password</span>
          <input
            type="password"
            autoComplete="current-password"
            value={current}
            onChange={(e) => setCurrent(e.target.value)}
            required
          />
        </label>
        <label className="field">
          <span>New password</span>
          <input
            type="password"
            autoComplete="new-password"
            minLength={8}
            maxLength={72}
            value={next}
            onChange={(e) => setNext(e.target.value)}
            required
          />
        </label>
        <label className="field">
          <span>New password again</span>
          <input
            type="password"
            autoComplete="new-password"
            minLength={8}
            maxLength={72}
            value={repeat}
            onChange={(e) => setRepeat(e.target.value)}
            required
          />
        </label>
        {error && <p className="alert alert--error">{error}</p>}
        {done && <p className="alert alert--good">Password changed.</p>}
        <button type="submit" className="button button--primary" disabled={busy}>
          {busy ? 'Saving…' : 'Change password'}
        </button>
      </form>

      <section className="card auth__card" style={{ marginTop: 16 }}>
        <h2>Active sessions</h2>
        <p style={{ margin: '0 0 12px', color: '#4b5563', fontSize: 14 }}>
          End every active sign-in on all browsers and devices immediately.
        </p>
        {sessionError && <p className="alert alert--error">{sessionError}</p>}
        <button
          type="button"
          className="button"
          data-testid="sign-out-everywhere"
          disabled={signingOut}
          onClick={() => void signOutEverywhere()}
        >
          {signingOut ? 'Signing out…' : 'Sign out everywhere'}
        </button>
      </section>
    </div>
  );
}
